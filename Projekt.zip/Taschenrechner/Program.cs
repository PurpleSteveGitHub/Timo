﻿


//if (Zahl2 == 0)
//{
//    Console.WriteLine("Gleich Schmiert Das System ab, ändere diese Zahl sofort oder ich lasse das System abstürzen");
//    Console.WriteLine("2. Zahl: ");
//    string eingabeZahl3 = Console.ReadLine();
//    bool isNum3 = int.TryParse(eingabeZahl3, out int Zahl3);
//    Zahl2 = Zahl3;
//}




//int result = Zahl1 * Zahl2;
//Console.WriteLine(Zahl1 + " * " + Zahl2 + " = " + result);
//if (result < 0)
//{
//    Console.WriteLine("Die Zahl ist kleiner als 0");
//}




//result = Zahl1 / Zahl2;
//Console.WriteLine(Zahl1 + " / " + Zahl2 + " = " + result);
//if (result < 0)
//{
//    Console.WriteLine("Die Zahl ist kleiner als 0");
//}



//result = Zahl1 - Zahl2;
//Console.WriteLine(Zahl1 + " - " + Zahl2 + " = " + result);
//if (result < 0)
//{
//    Console.WriteLine("Die Zahl ist kleiner als 0");
//}




//result = Zahl1 + Zahl2;
//Console.WriteLine(Zahl1 + " + " + Zahl2 + " = " + result);
//if (result < 0)
//{
//    Console.WriteLine("Die Zahl ist kleiner als 0");
//}



using System.ComponentModel.Design;
using System.Drawing;
using System.Numerics;





while (true) 
{
    Console.Clear();

    Console.WriteLine("\r\n _______ _______ _______ _______ __   __ _______ __    _ ______   _______ _______ __   __ __    _ _______ ______   \r\n|       |   _   |       |       |  | |  |       |  |  | |    _ | |       |       |  | |  |  |  | |       |    _ |  \r\n|_     _|  |_|  |  _____|       |  |_|  |    ___|   |_| |   | || |    ___|       |  |_|  |   |_| |    ___|   | ||  \r\n  |   | |       | |_____|       |       |   |___|       |   |_||_|   |___|       |       |       |   |___|   |_||_ \r\n  |   | |       |_____  |      _|       |    ___|  _    |    __  |    ___|      _|       |  _    |    ___|    __  |\r\n  |   | |   _   |_____| |     |_|   _   |   |___| | |   |   |  | |   |___|     |_|   _   | | |   |   |___|   |  | |\r\n  |___| |__| |__|_______|_______|__| |__|_______|_|  |__|___|  |_|_______|_______|__| |__|_|  |__|_______|___|  |_|\r\n");

    

    Console.WriteLine("Bitte erste Zahl eingeben!");



    double result = 0;
    bool istzahl = false;
        int crash1 = 0;
        int crash2 = 0;

    double ZahlOut1 = 0;
    double ZahlOut2 = 0;

    double Zahl1 = 0;
    double Zahl2 = 0;

    do {
        Console.WriteLine("1. Zahl: ");
        string eingabeZahl1 = Console.ReadLine();
        istzahl = double.TryParse(eingabeZahl1, out Zahl1);
    }while(istzahl ==  false);


    do {
        Console.WriteLine("2. Zahl: ");
        string eingabeZahl2 = Console.ReadLine();
        istzahl = double.TryParse(eingabeZahl2, out Zahl2);
    }while(istzahl == false);

    Console.WriteLine("Operator: ");
    string eingabeOperator = Console.ReadLine();
    bool ischar = char.TryParse(eingabeOperator, out char Operator);


if (Operator == '+')
    {
    result = Zahl1 + Zahl2;
    Console.WriteLine(Zahl1 + " + " + Zahl2 + " = " + result);
    }

if (Operator == '-')
    {
    result = Zahl1 - Zahl2;
    Console.WriteLine(Zahl1 + " - " + Zahl2 + " = " + result);
    }

if (Operator == '*')
    {
    result = Zahl1 * Zahl2;
    Console.WriteLine(Zahl1 + " * " + Zahl2 + " = " + result);
    }

if (Operator == '/')
    {
    result = Zahl1 / Zahl2;
    Console.WriteLine(Zahl1 + " / " + Zahl2 + " = " + result);
    }


if (result == 0)
    {
    Console.WriteLine("Error");
    }



    Console.WriteLine("Weitermachen?");


    string input = Console.ReadLine();
    if (input == "n")
    {
        Environment.Exit(0);
    }
    else if (input == "y")
    {

    }
}
//int ErrorCode = 0;

//do 
//{
//    Console.WriteLine(ErrorCode);
//    ErrorCode = ErrorCode + 100;
//}while ();

//do 
//{
//    if (true)
//    {
//        do
//        {
//            if (true)
//            {
//                Console.ReadKey(true);

//                string input = Console.ReadLine();
//                if (input == "e")
//                {
//                    Console.WriteLine("GoodBye!");
//                }
               
//            }
//        } while (false);
//    }
//}while(true);





























//int i = 0;
//do
//{
//    i = i + 5;
//    Console.WriteLine(i);

//} while (i <= 95);



//int i = 5;
//do
//{
//    Console.WriteLine(i);
//    i = i + 5;
//} while (i <= 100);




























//for (int i = 5; i <= 100; i = i+5)
//{
//    Console.WriteLine(i);    
//}





















