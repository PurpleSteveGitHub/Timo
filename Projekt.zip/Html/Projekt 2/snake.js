document.addEventListener('DOMContentLoaded', () => {
    const gameContainer = document.querySelector('.game-container');
    const snake = document.getElementById('snake');
    const food = document.getElementById('food');
    const scoreDisplay = document.createElement('div');
    let snakeX = 10;
    let snakeY = 10;
    let snakeXSpeed = 0;
    let snakeYSpeed = 0;
    let foodX = 0;
    let foodY = 0;
    let score = 0;
    const snakeBody = [{ x: 10, y: 10 }];
    let snakeLength = 1;
    let lastKeyPressed = '';
  
    function randomPosition() {
      return Math.floor(Math.random() * 20) * 20;
    }
  
    function createScoreDisplay() {
      scoreDisplay.textContent = 'Score: 0';
      gameContainer.appendChild(scoreDisplay);
    }
  
    function updateScoreDisplay() {
      scoreDisplay.textContent = `Score: ${score}`;
    }
  
    function updateFoodPosition() {
      foodX = randomPosition();
      foodY = randomPosition();
      food.style.left = `${foodX}px`;
      food.style.top = `${foodY}px`;
    }
  
    function updateSnakePosition() {
      snakeX += snakeXSpeed;
      snakeY += snakeYSpeed;
      snake.style.left = `${snakeX}px`;
      snake.style.top = `${snakeY}px`;
    }
  
    function checkCollision() {
      if (snakeX === foodX && snakeY === foodY) {
        score += 10;
        updateScoreDisplay();
        updateFoodPosition();
        snakeLength++;
      }
  
      if (snakeX < 0 || snakeX >= 400 || snakeY < 0 || snakeY >= 400) {
        gameOver();
      }
  
      for (let i = 1; i < snakeBody.length; i++) {
        if (snakeX === snakeBody[i].x && snakeY === snakeBody[i].y) {
          gameOver();
        }
      }
    }
  
    function updateSnakeBody() {
      snakeBody.unshift({ x: snakeX, y: snakeY });
      if (snakeBody.length > snakeLength) {
        snakeBody.pop();
      }
    }
  
    function drawSnakeBody() {
      for (let i = 0; i < snakeBody.length; i++) {
        const segment = document.createElement('div');
        segment.className = 'snake-segment';
        segment.style.left = `${snakeBody[i].x}px`;
        segment.style.top = `${snakeBody[i].y}px`;
        gameContainer.appendChild(segment);
      }
    }
  
    function clearSnakeBody() {
      const segments = document.querySelectorAll('.snake-segment');
      segments.forEach(segment => segment.remove());
    }
  
    function updateSnake() {
      clearSnakeBody();
      updateSnakeBody();
      drawSnakeBody();
    }
      
    function gameLoop() {
      updateSnakePosition();
      checkCollision();
      updateSnake();
    }
  
    function handleKeyPress(event) {
      const key = event.key;
      if (key === 'ArrowUp' && lastKeyPressed !== 'ArrowDown') {
        snakeXSpeed = 0;
        snakeYSpeed = -20;
        lastKeyPressed = key;
      } else if (key === 'ArrowDown' && lastKeyPressed !== 'ArrowUp') {
        snakeXSpeed = 0;
        snakeYSpeed = 20;
        lastKeyPressed = key;
      } else if (key === 'ArrowLeft' && lastKeyPressed !== 'ArrowRight') {
        snakeXSpeed = -20;
        snakeYSpeed = 0;
        lastKeyPressed = key;
      } else if (key === 'ArrowRight' && lastKeyPressed !== 'ArrowLeft') {
        snakeXSpeed = 20;
        snakeYSpeed = 0;
        lastKeyPressed = key;
      }
    }
  
    createScoreDisplay();
    updateFoodPosition();
    setInterval(gameLoop, 100); // Game loop runs every 100 milliseconds
    document.addEventListener('keydown', handleKeyPress);
  });